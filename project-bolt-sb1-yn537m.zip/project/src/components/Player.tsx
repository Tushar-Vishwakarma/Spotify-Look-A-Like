import React from 'react';
import { Play, SkipBack, SkipForward, Repeat, Shuffle, Volume2 } from 'lucide-react';

const Player = () => {
  return (
    <div className="h-24 bg-[#181818] border-t border-[#282828] px-4 flex items-center justify-between">
      <div className="flex items-center w-1/3">
        <img
          src="https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3"
          alt="Current track"
          className="h-14 w-14 rounded object-cover"
        />
        <div className="ml-4">
          <div className="text-white text-sm font-semibold">Never Gonna Give You Up</div>
          <div className="text-gray-400 text-xs">Rick Astley</div>
        </div>
      </div>

      <div className="flex flex-col items-center w-1/3">
        <div className="flex items-center gap-4">
          <button className="text-gray-400 hover:text-white">
            <Shuffle className="w-5 h-5" />
          </button>
          <button className="text-gray-400 hover:text-white">
            <SkipBack className="w-5 h-5" />
          </button>
          <button className="bg-white rounded-full p-2 hover:scale-105 transition">
            <Play className="w-5 h-5 text-black" fill="black" />
          </button>
          <button className="text-gray-400 hover:text-white">
            <SkipForward className="w-5 h-5" />
          </button>
          <button className="text-gray-400 hover:text-white">
            <Repeat className="w-5 h-5" />
          </button>
        </div>
        <div className="flex items-center w-full max-w-md gap-2 mt-2">
          <span className="text-xs text-gray-400">2:10</span>
          <div className="flex-1 h-1 bg-gray-600 rounded-full">
            <div className="w-1/3 h-full bg-white rounded-full"></div>
          </div>
          <span className="text-xs text-gray-400">3:30</span>
        </div>
      </div>

      <div className="flex items-center justify-end w-1/3 gap-2">
        <Volume2 className="w-5 h-5 text-gray-400" />
        <div className="w-24 h-1 bg-gray-600 rounded-full">
          <div className="w-2/3 h-full bg-white rounded-full"></div>
        </div>
      </div>
    </div>
  );
};

export default Player;