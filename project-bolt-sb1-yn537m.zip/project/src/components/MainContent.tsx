import React from 'react';
import { Play, Clock } from 'lucide-react';

const MainContent = () => {
  const playlists = [
    {
      title: "Today's Top Hits",
      description: "Jung Kook is on top of the Hottest 50!",
      image: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3"
    },
    {
      title: "RapCaviar",
      description: "New music from Drake, Travis Scott and more",
      image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3"
    },
    {
      title: "All Out 2010s",
      description: "The biggest songs of the 2010s",
      image: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3"
    },
    {
      title: "Rock Classics",
      description: "Rock legends & epic songs",
      image: "https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3"
    }
  ];

  const recentlyPlayed = [
    { title: "Never Gonna Give You Up", artist: "Rick Astley", duration: "3:32" },
    { title: "Bohemian Rhapsody", artist: "Queen", duration: "5:55" },
    { title: "Sweet Child O' Mine", artist: "Guns N' Roses", duration: "5:56" },
    { title: "Billie Jean", artist: "Michael Jackson", duration: "4:54" },
    { title: "Smells Like Teen Spirit", artist: "Nirvana", duration: "5:01" }
  ];

  return (
    <div className="flex-1 bg-gradient-to-b from-[#1e1e1e] to-[#121212] overflow-auto">
      <div className="p-8">
        <h1 className="text-2xl font-bold text-white mb-6">Good afternoon</h1>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-8">
          {playlists.map((playlist, index) => (
            <div key={index} className="bg-[#181818] group rounded-lg p-4 hover:bg-[#282828] transition-all duration-300 cursor-pointer">
              <div className="relative">
                <img src={playlist.image} alt={playlist.title} className="w-full aspect-square object-cover rounded-md mb-4" />
                <button className="absolute bottom-4 right-4 bg-green-500 rounded-full p-3 opacity-0 group-hover:opacity-100 transition-all duration-300 shadow-lg hover:scale-105 hover:bg-green-400">
                  <Play className="w-6 h-6 text-black" fill="black" />
                </button>
              </div>
              <h3 className="text-white font-semibold mb-1">{playlist.title}</h3>
              <p className="text-gray-400 text-sm">{playlist.description}</p>
            </div>
          ))}
        </div>

        <h2 className="text-xl font-bold text-white mb-4">Recently played</h2>
        <div className="bg-[#181818] rounded-lg">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-[#282828] text-gray-400 text-sm">
                <th className="p-4 font-normal">#</th>
                <th className="p-4 font-normal">Title</th>
                <th className="p-4 font-normal">Artist</th>
                <th className="p-4 font-normal"><Clock className="w-5 h-5" /></th>
              </tr>
            </thead>
            <tbody>
              {recentlyPlayed.map((song, index) => (
                <tr key={index} className="text-gray-300 hover:bg-[#282828] group">
                  <td className="p-4">{index + 1}</td>
                  <td className="p-4 font-medium text-white">{song.title}</td>
                  <td className="p-4">{song.artist}</td>
                  <td className="p-4">{song.duration}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default MainContent;